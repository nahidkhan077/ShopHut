ShopHut — Android + Website + Backend Starter

এই প্যাকেজে আছে:
1) website/ — মোবাইল-ফ্রেন্ডলি মার্কেটপ্লেস ওয়েবসাইট (PWA-ready)
2) backend/ — Node.js + Express + SQLite API
3) android/ — Android Studio WebView অ্যাপের প্রজেক্ট

চালানোর নিয়ম:
A. Backend
- কম্পিউটারে Node.js 20+ ইনস্টল করুন।
- টার্মিনালে backend ফোল্ডারে যান।
- npm install
- .env.example কপি করে .env করুন এবং JWT_SECRET বদলান।
- npm start
- API চলবে http://localhost:4000

B. Website
- website/index.html ব্রাউজারে খুলে UI দেখা যাবে।
- API ব্যবহার করতে website/app.js-এ API_BASE পরিবর্তন করুন।
- অনলাইনে চালাতে HTTPS hosting-এ website ফোল্ডার এবং backend আলাদা server-এ deploy করুন।

C. Android
- Android Studio-তে android ফোল্ডার Open করুন।
- app/src/main/assets/website/ এর index.html-এ API_BASE আপনার live API URL দিন।
- Build > Build APK(s) নির্বাচন করুন।
- এই পরিবেশে APK compile/sign করা হয়নি; Android Studio প্রয়োজন।

ডেমো অ্যাডমিন:
- প্রথমে backend/.env-এ ADMIN_EMAIL এবং ADMIN_PASSWORD দিন।
- সার্ভার প্রথম চালুর সময় admin account তৈরি হবে।

গুরুত্বপূর্ণ:
- এটি একটি কাজ করার মতো development starter, এখনো production-ready ব্যবসা নয়।
- আসল অনলাইন চালুর আগে domain, hosting, HTTPS, secure secrets, database backup,
  seller verification, privacy/terms, customer support, refund policy এবং payment gateway
  merchant account/API integration লাগবে।
- বর্তমানে অর্ডার Cash on Delivery (COD) হিসেবে তৈরি হয়; অনলাইন পেমেন্ট/বিক্রেতাকে payout
  স্বয়ংক্রিয়ভাবে চালু নেই।
- বাংলাদেশে ব্যবসা ও পেমেন্ট চালুর আগে প্রযোজ্য আইন, ট্রেড লাইসেন্স, কর এবং পেমেন্ট
  provider-এর merchant শর্ত যাচাই করুন।


Android APK তৈরির সহজ বিকল্প (কম্পিউটার ছাড়াও, GitHub অ্যাকাউন্ট থাকলে):
1. ZIP ফাইলটি Extract করে GitHub-এ নতুন repository তৈরি করে সব ফাইল Upload করুন।
2. repository-এর Actions tab খুলুন।
3. “Build ShopHut Android APK” workflow নির্বাচন করে Run workflow চাপুন।
4. কাজ শেষ হলে workflow run-এর Artifacts অংশ থেকে ShopHut-debug-apk ডাউনলোড করুন।
5. এটি পরীক্ষামূলক debug APK; Play Store release-এর জন্য আলাদা signing ও পরীক্ষা লাগবে।

সতর্কতা: বর্তমান অ্যাপটি starter prototype। পূর্ণ checkout UI, production owner dashboard, payment gateway, seller payout, push notification, security review এবং live hosting এখনো সম্পন্ন নয়। তাই এটিকে এখনই বাস্তব গ্রাহকের কাছে চালু করবেন না।
