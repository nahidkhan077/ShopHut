require("dotenv").config();
const express = require("express");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const DB = require("better-sqlite3");

const app = express();
const db = new DB(process.env.DB_FILE || "shophut.sqlite");
const PORT = Number(process.env.PORT || 4000);
const SECRET = process.env.JWT_SECRET;
if (!SECRET) throw new Error("JWT_SECRET is required. Copy .env.example to .env and set it.");

app.use(cors({ origin: process.env.CORS_ORIGIN || "*" }));
app.use(express.json({ limit: "1mb" }));

db.exec(`
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'customer', created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS products(
 id INTEGER PRIMARY KEY AUTOINCREMENT, seller_id INTEGER NOT NULL, name TEXT NOT NULL,
 description TEXT DEFAULT '', price REAL NOT NULL, image_url TEXT DEFAULT '',
 stock INTEGER NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(seller_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS orders(
 id INTEGER PRIMARY KEY AUTOINCREMENT, customer_id INTEGER NOT NULL, total REAL NOT NULL,
 commission REAL NOT NULL, status TEXT NOT NULL DEFAULT 'pending',
 customer_name TEXT NOT NULL, phone TEXT NOT NULL, address TEXT NOT NULL,
 payment_method TEXT NOT NULL DEFAULT 'COD', created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(customer_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS order_items(
 id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER NOT NULL, product_id INTEGER NOT NULL,
 seller_id INTEGER NOT NULL, product_name TEXT NOT NULL, quantity INTEGER NOT NULL,
 unit_price REAL NOT NULL, FOREIGN KEY(order_id) REFERENCES orders(id)
);
`);

const adminEmail = process.env.ADMIN_EMAIL || "admin@shophut.local";
const adminPassword = process.env.ADMIN_PASSWORD || "ChangeThisAdminPassword123!";
if (!db.prepare("SELECT id FROM users WHERE email=?").get(adminEmail)) {
  db.prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)")
    .run("ShopHut Admin", adminEmail, bcrypt.hashSync(adminPassword, 12), "admin");
}

function auth(req,res,next) {
  const token = (req.headers.authorization || "").replace(/^Bearer\s+/i, "");
  try { req.user = jwt.verify(token, SECRET); next(); }
  catch { res.status(401).json({error:"লগইন করুন"}); }
}
function role(...roles) {
  return (req,res,next) => roles.includes(req.user.role) ? next() : res.status(403).json({error:"অনুমতি নেই"});
}
function tokenFor(user) { return jwt.sign({id:user.id, role:user.role, email:user.email}, SECRET, {expiresIn:"7d"}); }
function safeUser(u) { return {id:u.id,name:u.name,email:u.email,role:u.role}; }

app.get("/api/health", (_,res)=>res.json({ok:true,service:"ShopHut API"}));

app.post("/api/register", (req,res)=>{
  const {name,email,password,role:requestedRole="customer"} = req.body || {};
  if (!name || !email || !password || String(password).length < 8)
    return res.status(400).json({error:"নাম, ইমেইল এবং কমপক্ষে ৮ অক্ষরের পাসওয়ার্ড দিন"});
  const userRole = requestedRole === "seller" ? "seller" : "customer";
  try {
    const info = db.prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)")
      .run(String(name).trim(),String(email).toLowerCase().trim(),bcrypt.hashSync(password,12),userRole);
    const user = db.prepare("SELECT * FROM users WHERE id=?").get(info.lastInsertRowid);
    res.json({token:tokenFor(user),user:safeUser(user)});
  } catch { res.status(409).json({error:"এই ইমেইল দিয়ে আগে অ্যাকাউন্ট খোলা হয়েছে"}); }
});

app.post("/api/login",(req,res)=>{
  const {email,password} = req.body || {};
  const user = db.prepare("SELECT * FROM users WHERE email=?").get(String(email||"").toLowerCase().trim());
  if (!user || !bcrypt.compareSync(password||"",user.password_hash)) return res.status(401).json({error:"ইমেইল বা পাসওয়ার্ড সঠিক নয়"});
  res.json({token:tokenFor(user),user:safeUser(user)});
});

app.get("/api/products",(req,res)=>{
  const rows = db.prepare(`SELECT p.id,p.name,p.description,p.price,p.image_url,p.stock,u.name seller_name
    FROM products p JOIN users u ON u.id=p.seller_id WHERE p.active=1 ORDER BY p.id DESC`).all();
  res.json(rows);
});
app.post("/api/products",auth,role("seller","admin"),(req,res)=>{
  const {name,description="",price,image_url="",stock=0} = req.body || {};
  if (!name || !Number.isFinite(Number(price)) || Number(price)<=0 || !Number.isInteger(Number(stock)) || Number(stock)<0)
    return res.status(400).json({error:"পণ্যের নাম, সঠিক দাম এবং স্টক দিন"});
  const info = db.prepare("INSERT INTO products(seller_id,name,description,price,image_url,stock) VALUES(?,?,?,?,?,?)")
    .run(req.user.id,String(name),String(description),Number(price),String(image_url),Number(stock));
  res.json({id:info.lastInsertRowid,ok:true});
});
app.get("/api/my/products",auth,role("seller","admin"),(req,res)=>{
  res.json(db.prepare("SELECT * FROM products WHERE seller_id=? ORDER BY id DESC").all(req.user.id));
});

app.post("/api/orders",auth,role("customer","admin"),(req,res)=>{
  const {items,customer_name,phone,address} = req.body || {};
  if (!Array.isArray(items) || !items.length || !customer_name || !phone || !address)
    return res.status(400).json({error:"পণ্য, নাম, ফোন ও ঠিকানা পূরণ করুন"});
  const getProduct = db.prepare("SELECT * FROM products WHERE id=? AND active=1");
  let lines=[], total=0;
  for (const item of items) {
    const p=getProduct.get(Number(item.product_id)), q=Number(item.quantity);
    if (!p || !Number.isInteger(q) || q<1 || q>p.stock) return res.status(400).json({error:"পণ্য বা স্টকের সমস্যা"});
    lines.push({p,q}); total += p.price*q;
  }
  const commission = total * Number(process.env.COMMISSION_PERCENT || 10)/100;
  const create = db.transaction(()=>{
    const o=db.prepare("INSERT INTO orders(customer_id,total,commission,customer_name,phone,address) VALUES(?,?,?,?,?,?)")
      .run(req.user.id,total,commission,String(customer_name),String(phone),String(address));
    const ins=db.prepare("INSERT INTO order_items(order_id,product_id,seller_id,product_name,quantity,unit_price) VALUES(?,?,?,?,?,?)");
    const dec=db.prepare("UPDATE products SET stock=stock-? WHERE id=?");
    for (const l of lines) { ins.run(o.lastInsertRowid,l.p.id,l.p.seller_id,l.p.name,l.q,l.p.price); dec.run(l.q,l.p.id); }
    return o.lastInsertRowid;
  });
  res.json({ok:true,order_id:create(),total,commission_estimate:commission,payment_method:"COD"});
});
app.get("/api/my/orders",auth,(req,res)=>{
  const rows=db.prepare("SELECT * FROM orders WHERE customer_id=? ORDER BY id DESC").all(req.user.id);
  res.json(rows);
});
app.get("/api/admin/summary",auth,role("admin"),(_,res)=>{
  const users=db.prepare("SELECT COUNT(*) n FROM users").get().n;
  const sellers=db.prepare("SELECT COUNT(*) n FROM users WHERE role='seller'").get().n;
  const products=db.prepare("SELECT COUNT(*) n FROM products").get().n;
  const stats=db.prepare("SELECT COUNT(*) orders,COALESCE(SUM(total),0) sales,COALESCE(SUM(commission),0) commission FROM orders").get();
  const recent=db.prepare("SELECT id,total,commission,status,customer_name,phone,created_at FROM orders ORDER BY id DESC LIMIT 50").all();
  res.json({users,sellers,products,...stats,recent});
});
app.patch("/api/admin/orders/:id",auth,role("admin"),(req,res)=>{
  const allowed=["confirmed","shipped","delivered","cancelled"];
  if (!allowed.includes(req.body.status)) return res.status(400).json({error:"Status সঠিক নয়"});
  const info=db.prepare("UPDATE orders SET status=? WHERE id=?").run(req.body.status,Number(req.params.id));
  res.json({ok:info.changes>0});
});

app.listen(PORT,()=>console.log(`ShopHut API running on ${PORT}`));
